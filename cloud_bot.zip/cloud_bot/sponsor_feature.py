import json
import re
from io import BytesIO
from pathlib import Path
from decimal import Decimal, InvalidOperation
from urllib.parse import quote

import discord


# =========================================================
# CLOUD PLAYZZ SPONSOR FEATURE
# Separate module for your existing bot.
#
# What this feature does:
# 1. Sends sponsor panel in sponsors channel
# 2. Creates private sponsor payment ticket
# 3. Generates UPI QR for micruva2828@okhdfcbank
# 4. Lets user upload payment screenshot in private channel
# 5. Admin manually approves payment
# 6. Updates sponsor leaderboard
# 7. Announces big sponsors in general channel
# =========================================================


# -------------------------
# SETTINGS
# -------------------------

SPONSOR_UPI_ID = "micruva2829@okhdfcbank"
SPONSOR_PAYEE_NAME = "CLOUD PLAYZZ"

SPONSORS_CHANNEL_KEYWORD = "sponsors"
SPONSOR_RANKS_CHANNEL_KEYWORD = "sponsor-ranks"
GENERAL_CHANNEL_NAME = "general"
ADMIN_CHANNEL_NAME = "admin"

ADMIN_ROLE_NAMES = ["Admin", "Moderator", "Mod", "Builder"]

HUGE_SPONSOR_AMOUNT = Decimal("10000")

PROJECT_ROOT = Path(__file__).resolve().parent.parent if Path(__file__).resolve().parent.name == "cloud_bot" else Path(__file__).resolve().parent
SPONSOR_DATA_FILE = PROJECT_ROOT / "sponsors_data.json"


# -------------------------
# DATA HANDLING
# -------------------------

def default_sponsor_data():
    return {
        "rank_message_id": None,
        "sponsors": {},
        "tickets": {}
    }


def load_sponsor_data():
    if not SPONSOR_DATA_FILE.exists():
        save_sponsor_data(default_sponsor_data())
        return default_sponsor_data()

    try:
        with SPONSOR_DATA_FILE.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        data = default_sponsor_data()

    base = default_sponsor_data()
    for key, value in base.items():
        data.setdefault(key, value)

    return data


def save_sponsor_data(data):
    SPONSOR_DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    with SPONSOR_DATA_FILE.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)


sponsor_data = load_sponsor_data()


# -------------------------
# HELPER FUNCTIONS
# -------------------------

def is_admin_or_builder(member: discord.Member) -> bool:
    if member.guild_permissions.administrator:
        return True

    return any(role.name in ADMIN_ROLE_NAMES for role in member.roles)


def get_text_channel_by_name(guild: discord.Guild, name: str):
    return discord.utils.get(guild.text_channels, name=name)


def get_text_channel_by_keyword(guild: discord.Guild, keyword: str):
    keyword = keyword.lower()

    for channel in guild.text_channels:
        if keyword in channel.name.lower():
            return channel

    return None


def is_sponsor_ticket_channel(channel: discord.TextChannel) -> bool:
    return channel.name.startswith("sponsor-")


def parse_amount(amount_text: str):
    cleaned = amount_text.replace("₹", "").replace(",", "").strip()

    try:
        amount = Decimal(cleaned)
    except InvalidOperation:
        return None

    if amount <= 0:
        return None

    return amount.quantize(Decimal("0.01"))


def amount_to_paise(amount: Decimal) -> int:
    return int((amount * 100).to_integral_value())


def paise_to_amount(paise: int) -> Decimal:
    return (Decimal(paise) / Decimal(100)).quantize(Decimal("0.01"))


def format_inr_from_paise(paise: int) -> str:
    amount = paise_to_amount(paise)

    if amount == amount.to_integral():
        return f"₹{int(amount)}"

    return f"₹{amount}"


def sponsor_tier(total_paise: int):
    amount = paise_to_amount(total_paise)

    if amount >= Decimal("10000"):
        return "🌟 LEGENDARY SPONSOR"
    if amount >= Decimal("5000"):
        return "💎 DIAMOND SPONSOR"
    if amount >= Decimal("1000"):
        return "🏆 GOLD SPONSOR"
    if amount >= Decimal("500"):
        return "🥈 SILVER SPONSOR"

    return "🥉 BRONZE SPONSOR"


def build_upi_link(amount: Decimal, user: discord.User | discord.Member):
    note = f"CLOUD PLAYZZ Sponsor {user.id}"

    return (
        "upi://pay?"
        f"pa={quote(SPONSOR_UPI_ID)}"
        f"&pn={quote(SPONSOR_PAYEE_NAME)}"
        f"&am={quote(str(amount))}"
        "&cu=INR"
        f"&tn={quote(note)}"
    )


def create_upi_qr_file(upi_link: str):
    try:
        import qrcode
    except ImportError:
        return None

    qr = qrcode.QRCode(
        version=1,
        box_size=10,
        border=4
    )

    qr.add_data(upi_link)
    qr.make(fit=True)

    image = qr.make_image(fill_color="black", back_color="white")

    image_bytes = BytesIO()
    image.save(image_bytes, format="PNG")
    image_bytes.seek(0)

    return discord.File(image_bytes, filename="cloud_playzz_sponsor_qr.png")


async def safe_dm(user: discord.User | discord.Member, message: str):
    try:
        await user.send(message)
        return True
    except Exception:
        return False


# =========================================================
# SPONSOR PANEL BUTTON
# =========================================================

class SponsorPanelView(discord.ui.View):
    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(
        label="Generate Sponsor QR",
        emoji="📲",
        style=discord.ButtonStyle.success,
        custom_id="generate_sponsor_qr"
    )
    async def generate_sponsor_qr(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(SponsorAmountModal(self.bot))


class SponsorAmountModal(discord.ui.Modal, title="CLOUD PLAYZZ Sponsor Payment"):
    amount = discord.ui.TextInput(
        label="Sponsor Amount in INR",
        placeholder="Example: 100, 500, 1000, 10000",
        required=True,
        max_length=10
    )

    contact = discord.ui.TextInput(
        label="Discord ID / Contact Info",
        placeholder="Example: Gamerforlife0554 / Instagram ID / phone optional",
        required=True,
        max_length=120
    )

    note = discord.ui.TextInput(
        label="Message / Reason for Sponsoring",
        placeholder="Optional message",
        required=False,
        style=discord.TextStyle.paragraph,
        max_length=300
    )

    def __init__(self, bot):
        super().__init__()
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction):
        guild = interaction.guild
        user = interaction.user

        if guild is None:
            await interaction.response.send_message(
                "This feature can only be used inside the server.",
                ephemeral=True
            )
            return

        amount_value = parse_amount(str(self.amount.value))

        if amount_value is None:
            await interaction.response.send_message(
                "Please enter a valid amount. Example: `100`, `500`, `1000`.",
                ephemeral=True
            )
            return

        ticket_channel = await create_sponsor_ticket(
            guild=guild,
            user=user,
            amount=amount_value,
            contact=str(self.contact.value),
            note=str(self.note.value),
            source_channel=interaction.channel
        )

        await interaction.response.send_message(
            f"✅ Your private sponsor payment channel has been created: {ticket_channel.mention}",
            ephemeral=True
        )


# =========================================================
# SPONSOR TICKET CREATION
# =========================================================

async def create_sponsor_ticket(
    guild: discord.Guild,
    user: discord.Member,
    amount: Decimal,
    contact: str,
    note: str,
    source_channel: discord.TextChannel
):
    ticket_name = f"sponsor-{user.name.lower()}-{user.id % 10000}"

    existing_ticket = discord.utils.get(guild.text_channels, name=ticket_name)

    if existing_ticket:
        return existing_ticket

    overwrites = {
        guild.default_role: discord.PermissionOverwrite(view_channel=False),
        user: discord.PermissionOverwrite(
            view_channel=True,
            send_messages=True,
            read_message_history=True,
            attach_files=True
        ),
        guild.me: discord.PermissionOverwrite(
            view_channel=True,
            send_messages=True,
            read_message_history=True,
            attach_files=True,
            manage_channels=True
        )
    }

    for role in guild.roles:
        if role.name in ADMIN_ROLE_NAMES:
            overwrites[role] = discord.PermissionOverwrite(
                view_channel=True,
                send_messages=True,
                read_message_history=True,
                attach_files=True,
                manage_channels=True
            )

    ticket_channel = await guild.create_text_channel(
        name=ticket_name,
        overwrites=overwrites,
        category=source_channel.category,
        reason=f"Sponsor payment ticket created for {user}"
    )

    user_id = str(user.id)
    channel_id = str(ticket_channel.id)

    sponsor_data["tickets"][channel_id] = {
        "user_id": user_id,
        "amount_requested_paise": amount_to_paise(amount),
        "contact": contact,
        "note": note,
        "status": "waiting_for_payment_screenshot"
    }
    save_sponsor_data(sponsor_data)

    upi_link = build_upi_link(amount, user)
    qr_file = create_upi_qr_file(upi_link)

    embed = discord.Embed(
        title="📲 CLOUD PLAYZZ Sponsor Payment",
        description=(
            f"Hello {user.mention}, thank you for supporting **CLOUD PLAYZZ**!\n\n"
            f"**Amount:** `{str(amount)}` INR\n"
            f"**UPI ID:** `{SPONSOR_UPI_ID}`\n\n"
            "**Steps:**\n"
            "1. Scan the QR code below using GPay / PhonePe / Paytm.\n"
            "2. Complete the payment.\n"
            "3. Send your payment screenshot in this private channel.\n"
            "4. Mention your Discord ID in the message.\n"
            "5. Admin will verify and approve your sponsor rank.\n\n"
            "⚠️ **Safety Note:** The bot cannot verify UPI payment automatically from screenshots. "
            "Admin approval is required after checking the real payment."
        ),
        color=discord.Color.green()
    )

    embed.add_field(name="Discord User", value=f"{user.mention}\n`{user}`", inline=False)
    embed.add_field(name="Contact Given", value=contact[:500], inline=False)

    if note.strip():
        embed.add_field(name="Sponsor Message", value=note[:500], inline=False)

    embed.set_footer(text="CLOUD PLAYZZ Sponsors")

    if qr_file:
        embed.set_image(url="attachment://cloud_playzz_sponsor_qr.png")
        await ticket_channel.send(embed=embed, file=qr_file)
    else:
        embed.add_field(
            name="UPI Payment Link",
            value=f"`{upi_link}`",
            inline=False
        )
        await ticket_channel.send(
            "⚠️ QR generation needs the Python package `qrcode`. Install it using `pip install qrcode[pil]`.\n"
            "For now, use the UPI link below.",
            embed=embed
        )

    await ticket_channel.send(
        f"{user.mention}, after payment, upload your screenshot here.\n"
        "Example message:\n"
        "```text\n"
        "Paid ₹500\n"
        "Discord ID: yourname#0000\n"
        "Screenshot attached\n"
        "```"
    )

    return ticket_channel


# =========================================================
# SPONSOR PANEL
# =========================================================

async def send_sponsor_panel(guild: discord.Guild, bot):
    sponsors_channel = get_text_channel_by_keyword(guild, SPONSORS_CHANNEL_KEYWORD)

    if sponsors_channel is None:
        print("Sponsors channel not found.")
        return

    async for msg in sponsors_channel.history(limit=50):
        if msg.author == bot.user and msg.embeds:
            if msg.embeds[0].title == "📲 CLOUD PLAYZZ Sponsor Support":
                print("Sponsor panel already exists.")
                return

    embed = discord.Embed(
        title="📲 CLOUD PLAYZZ Sponsor Support",
        description=(
            "Support **CLOUD PLAYZZ** and get ranked on the sponsor leaderboard!\n\n"
            "**How it works:**\n"
            "1. Click **Generate Sponsor QR**.\n"
            "2. Enter the amount you want to sponsor.\n"
            "3. The bot creates a private payment channel for you.\n"
            "4. Pay through UPI and upload your screenshot.\n"
            "5. Admin verifies the payment and updates your sponsor rank.\n\n"
            "✨ Top sponsors will be displayed in **sponsor-ranks**."
        ),
        color=discord.Color.blue()
    )

    embed.set_footer(text="CLOUD PLAYZZ Sponsors")

    await sponsors_channel.send(embed=embed, view=SponsorPanelView(bot))
    print("Sponsor panel sent.")


# =========================================================
# RANKING SYSTEM
# =========================================================

async def update_sponsor_ranks(guild: discord.Guild):
    ranks_channel = get_text_channel_by_keyword(guild, SPONSOR_RANKS_CHANNEL_KEYWORD)

    if ranks_channel is None:
        admin_channel = get_text_channel_by_name(guild, ADMIN_CHANNEL_NAME)
        if admin_channel:
            await admin_channel.send(
                "⚠️ Sponsor ranks channel not found. Create a channel named `sponsor-ranks`."
            )
        return

    sponsors = sponsor_data["sponsors"]

    sorted_sponsors = sorted(
        sponsors.items(),
        key=lambda item: item[1].get("total_paise", 0),
        reverse=True
    )[:10]

    if not sorted_sponsors:
        description = "No approved sponsors yet."
    else:
        lines = []

        medals = ["👑", "💎", "🥇", "🥈", "🥉", "✨", "✨", "✨", "✨", "✨"]

        for index, (user_id, info) in enumerate(sorted_sponsors, start=1):
            total_paise = info.get("total_paise", 0)
            display_name = info.get("display_name", f"User {user_id}")
            tier = sponsor_tier(total_paise)
            medal = medals[index - 1] if index <= len(medals) else "✨"

            lines.append(
                f"{medal} **#{index} — {display_name}**\n"
                f"╰ {tier} • **{format_inr_from_paise(total_paise)}** total\n"
            )

        description = "\n".join(lines)

    embed = discord.Embed(
        title="🤑 CLOUD PLAYZZ Sponsor Ranks",
        description=(
            "✨━━━━━━━━━━━━━━━━━━━━✨\n"
            "**Top 10 Sponsors**\n"
            "✨━━━━━━━━━━━━━━━━━━━━✨\n\n"
            f"{description}\n\n"
            "Thank you for supporting the community! ❤️"
        ),
        color=discord.Color.gold()
    )

    embed.set_footer(text="Sponsor ranks update after admin approval.")

    message_id = sponsor_data.get("rank_message_id")

    if message_id:
        try:
            old_msg = await ranks_channel.fetch_message(int(message_id))
            await old_msg.edit(embed=embed)
            return
        except Exception:
            sponsor_data["rank_message_id"] = None
            save_sponsor_data(sponsor_data)

    new_msg = await ranks_channel.send(embed=embed)
    sponsor_data["rank_message_id"] = new_msg.id
    save_sponsor_data(sponsor_data)


async def announce_big_sponsor(guild: discord.Guild, member: discord.Member, amount: Decimal):
    general_channel = get_text_channel_by_name(guild, GENERAL_CHANNEL_NAME)

    if general_channel is None:
        return

    embed = discord.Embed(
        title="🌟 HUGE SPONSOR ALERT 🌟",
        description=(
            "✨━━━━━━━━━━━━━━━━━━━━✨\n"
            f"Massive thanks to {member.mention} for sponsoring **₹{amount}** to **CLOUD PLAYZZ**!\n\n"
            "Your support helps us improve the server, host better tournaments, "
            "build more community features, and grow this gaming family stronger.\n\n"
            "Everyone, show some love to our sponsor! ❤️🔥\n"
            "✨━━━━━━━━━━━━━━━━━━━━✨"
        ),
        color=discord.Color.gold()
    )

    embed.set_footer(text="CLOUD PLAYZZ Sponsor Appreciation")

    await general_channel.send(embed=embed)


async def approve_sponsor(
    guild: discord.Guild,
    bot,
    user_id: str,
    amount: Decimal,
    approved_by: discord.Member,
    source_channel: discord.TextChannel
):
    member = guild.get_member(int(user_id))

    if member is None:
        try:
            member = await guild.fetch_member(int(user_id))
        except Exception:
            await source_channel.send("Could not find that user in the server.")
            return

    amount_paise = amount_to_paise(amount)

    if user_id not in sponsor_data["sponsors"]:
        sponsor_data["sponsors"][user_id] = {
            "display_name": member.display_name,
            "total_paise": 0,
            "approved_count": 0
        }

    sponsor_data["sponsors"][user_id]["display_name"] = member.display_name
    sponsor_data["sponsors"][user_id]["total_paise"] += amount_paise
    sponsor_data["sponsors"][user_id]["approved_count"] += 1

    channel_id = str(source_channel.id)

    if channel_id in sponsor_data["tickets"]:
        sponsor_data["tickets"][channel_id]["status"] = "approved"
        sponsor_data["tickets"][channel_id]["approved_amount_paise"] = amount_paise
        sponsor_data["tickets"][channel_id]["approved_by"] = str(approved_by.id)

    save_sponsor_data(sponsor_data)

    await source_channel.send(
        f"✅ Sponsor payment approved!\n"
        f"User: {member.mention}\n"
        f"Amount: **₹{amount}**\n"
        f"Approved by: {approved_by.mention}"
    )

    await safe_dm(
        member,
        f"✅ **Sponsor Payment Approved!**\n\n"
        f"Thank you for sponsoring **₹{amount}** to CLOUD PLAYZZ.\n"
        "Your sponsor rank has been updated."
    )

    await update_sponsor_ranks(guild)

    if amount >= HUGE_SPONSOR_AMOUNT:
        await announce_big_sponsor(guild, member, amount)


# =========================================================
# MESSAGE / COMMAND HANDLER
# =========================================================

async def handle_sponsor_message(message: discord.Message, bot) -> bool:
    if message.author.bot or not message.guild:
        return False

    content = message.content.strip()
    lower = content.lower()

    # Admin command: send sponsor panel manually
    if lower == "!sponsorpanel":
        if not is_admin_or_builder(message.author):
            await message.reply("Only admins/builders can use this command.")
            return True

        await send_sponsor_panel(message.guild, bot)
        await message.reply("✅ Sponsor panel checked/sent.")
        return True

    # Admin command: refresh sponsor ranks
    if lower == "!sponsorranks":
        if not is_admin_or_builder(message.author):
            await message.reply("Only admins/builders can use this command.")
            return True

        await update_sponsor_ranks(message.guild)
        await message.reply("✅ Sponsor ranks updated.")
        return True

    # Admin command:
    # Inside sponsor ticket: !approvesponsor 500
    # Outside ticket: !approvesponsor @user 500
    if lower.startswith("!approvesponsor"):
        if not is_admin_or_builder(message.author):
            await message.reply("Only admins/builders can approve sponsors.")
            return True

        mentioned_user = message.mentions[0] if message.mentions else None

        clean_content = re.sub(r"<@!?\d+>", "", content)
        clean_content = clean_content.replace(",", "")
        amount_match = re.search(r"(\d+(?:\.\d{1,2})?)", clean_content)

        if amount_match is None:
            await message.reply(
                "Usage:\n"
                "`!approvesponsor 500` inside sponsor ticket\n"
                "or\n"
                "`!approvesponsor @user 500`"
            )
            return True

        amount = parse_amount(amount_match.group(1))

        if amount is None:
            await message.reply("Please enter a valid amount.")
            return True

        if amount > Decimal("100000"):
            await message.reply("Amount looks too high. Please check and enter the real sponsor amount.")
            return True

        user_id = None

        if mentioned_user:
            user_id = str(mentioned_user.id)
        else:
            ticket_info = sponsor_data["tickets"].get(str(message.channel.id))
            if ticket_info:
                user_id = ticket_info.get("user_id")

        if user_id is None:
            await message.reply(
                "I could not find which user to approve. Use `!approvesponsor @user amount`."
            )
            return True

        await approve_sponsor(
            guild=message.guild,
            bot=bot,
            user_id=user_id,
            amount=amount,
            approved_by=message.author,
            source_channel=message.channel
        )

        return True

    # Admin command: reject sponsor ticket
    if lower.startswith("!rejectsponsor"):
        if not is_admin_or_builder(message.author):
            await message.reply("Only admins/builders can reject sponsor tickets.")
            return True

        channel_id = str(message.channel.id)

        if channel_id not in sponsor_data["tickets"]:
            await message.reply("This is not a sponsor ticket channel.")
            return True

        sponsor_data["tickets"][channel_id]["status"] = "rejected"
        sponsor_data["tickets"][channel_id]["rejected_by"] = str(message.author.id)
        save_sponsor_data(sponsor_data)

        await message.reply("❌ Sponsor ticket marked as rejected.")
        return True

    # User uploads payment proof inside sponsor ticket
    if isinstance(message.channel, discord.TextChannel) and is_sponsor_ticket_channel(message.channel):
        if message.attachments:
            ticket_info = sponsor_data["tickets"].get(str(message.channel.id))

            if ticket_info:
                ticket_info["status"] = "screenshot_received"
                save_sponsor_data(sponsor_data)

            admin_channel = get_text_channel_by_name(message.guild, ADMIN_CHANNEL_NAME)

            if admin_channel:
                embed = discord.Embed(
                    title="📸 Sponsor Payment Screenshot Received",
                    description=(
                        f"User: {message.author.mention}\n"
                        f"Ticket: {message.channel.mention}\n"
                        f"Message: [Open Screenshot Message]({message.jump_url})\n\n"
                        "After checking the real payment, approve with:\n"
                        "`!approvesponsor amount` inside the sponsor ticket."
                    ),
                    color=discord.Color.orange()
                )

                await admin_channel.send(embed=embed)

            await message.reply(
                "✅ Screenshot received. Admin will verify the payment and update your sponsor rank soon."
            )

            return True

    return False


# =========================================================
# SETUP FUNCTION FOR YOUR MAIN BOT
# =========================================================

def setup_sponsor_feature(bot):
    if getattr(bot, "_sponsor_feature_setup", False):
        return

    bot.add_view(SponsorPanelView(bot))
    bot._sponsor_feature_setup = True
