import asyncio
import json
import os
import sys
from pathlib import Path
from io import BytesIO
from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo

try:
    from cloud_bot.sponsor_feature import setup_sponsor_feature, send_sponsor_panel, handle_sponsor_message
except ImportError:
    from sponsor_feature import setup_sponsor_feature, send_sponsor_panel, handle_sponsor_message

import discord
from discord.ext import tasks

# =========================================================
# CLOUD PLAYZZ FULL BOT
# Features:
# 1. Introduction auto reply
# 2. Discord service ticket system
# 3. Ticket close + transcript
# 4. Sunday + Monthly tournament system
# =========================================================

PROJECT_ROOT = Path(__file__).resolve().parent.parent if Path(__file__).resolve().parent.name == "cloud_bot" else Path(__file__).resolve().parent

TOKEN = os.getenv("DISCORD_BOT_TOKEN")

# Fix for Windows CTRL + C event loop issue
if os.name == "nt":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


# =========================================================
# SETTINGS
# =========================================================

# Introduction system
INTRO_KEYWORDS = ["introduction", "introductions", "intro", "introduce"]

# Service ticket system
SERVICE_CHANNEL_KEYWORD = "server-build"
ADMIN_CHANNEL_NAME = "admin"
TICKET_CLOSE_DELAY_SECONDS = 5

# Admin roles allowed to use service/tournament controls
ADMIN_ROLE_NAMES = ["Admin", "Moderator", "Mod", "Builder"]

# Tournament channels
GENERAL_CHANNEL_NAME = "general"
SUNDAY_CHANNEL_KEYWORD = "daily-sunday-tournament"
MONTHLY_CHANNEL_KEYWORD = "monthly-end-tournament"
TOURNAMENT_CODE_CHANNEL_NAME = "tournament-code"

# India time
TIMEZONE = ZoneInfo("Asia/Kolkata")

# Tournament schedule
FRIDAY_REGISTRATION_OPEN = time(10, 0)    # Friday 10:00 AM
FRIDAY_REGISTRATION_CLOSE = time(22, 0)   # Friday 10:00 PM
SUNDAY_TOURNAMENT_ALERT = time(10, 0)     # Sunday 10:00 AM

# Monthly end tournament:
# This bot treats the LAST SUNDAY of the month as monthly tournament day.
MONTHLY_TOURNAMENT_ALERT = time(10, 0)

# Qualified players get DM reminders during the last 7 days before monthly tournament day.
MONTHLY_REMINDER_TIME = time(10, 0)
MONTHLY_REMINDER_DAYS_BEFORE = 7

DATA_FILE = PROJECT_ROOT / "tournament_data.json"


# =========================================================
# DISCORD INTENTS
# =========================================================

intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.members = True


# =========================================================
# DATA HANDLING FOR TOURNAMENT SYSTEM
# =========================================================

def default_data():
    return {
        "sunday": {
            "registration_open": False,
            "registration_message_id": None,
            "registered_user_ids": [],
            "last_open_date": None,
            "last_close_date": None,
            "last_sunday_alert_date": None
        },
        "monthly": {
            "qualified_user_ids": [],
            "weekly_winners_history": [],
            "last_monthly_alert_month": None,
            "last_monthly_reminder_date": None
        }
    }


def load_data():
    if not DATA_FILE.exists():
        save_data(default_data())
        return default_data()

    try:
        with DATA_FILE.open("r", encoding="utf-8") as f:
            loaded_data = json.load(f)
    except Exception:
        loaded_data = default_data()

    base = default_data()

    for section, value in base.items():
        if section not in loaded_data:
            loaded_data[section] = value
        elif isinstance(value, dict):
            for key, default_value in value.items():
                loaded_data[section].setdefault(key, default_value)

    return loaded_data


def save_data(current_data):
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    with DATA_FILE.open("w", encoding="utf-8") as f:
        json.dump(current_data, f, indent=4)


data = load_data()


# =========================================================
# COMMON HELPER FUNCTIONS
# =========================================================

def now_ist():
    return datetime.now(TIMEZONE)


def date_key(dt=None):
    if dt is None:
        dt = now_ist()
    return dt.strftime("%Y-%m-%d")


def month_key(dt=None):
    if dt is None:
        dt = now_ist()
    return dt.strftime("%Y-%m")


def is_admin_or_builder(member: discord.Member) -> bool:
    if member.guild_permissions.administrator:
        return True

    return any(role.name in ADMIN_ROLE_NAMES for role in member.roles)


def is_ticket_channel(channel: discord.TextChannel) -> bool:
    return channel.name.startswith("ticket-")


def get_text_channel_by_name(guild: discord.Guild, name: str):
    return discord.utils.get(guild.text_channels, name=name)


def get_text_channel_by_keyword(guild: discord.Guild, keyword: str):
    keyword = keyword.lower()

    for channel in guild.text_channels:
        if keyword in channel.name.lower():
            return channel

    return None


def get_mention_list(user_ids):
    if not user_ids:
        return "No players yet."

    return "\n".join([f"<@{user_id}>" for user_id in user_ids])


def last_sunday_of_month(dt=None):
    if dt is None:
        dt = now_ist()

    year = dt.year
    month = dt.month

    if month == 12:
        first_next_month = datetime(year + 1, 1, 1, tzinfo=TIMEZONE)
    else:
        first_next_month = datetime(year, month + 1, 1, tzinfo=TIMEZONE)

    last_day = first_next_month - timedelta(days=1)

    # Python weekday: Monday=0, Sunday=6
    days_back = (last_day.weekday() - 6) % 7
    return last_day - timedelta(days=days_back)


def is_monthly_tournament_day(dt=None):
    if dt is None:
        dt = now_ist()

    monthly_day = last_sunday_of_month(dt)
    return dt.date() == monthly_day.date()


def is_within_monthly_reminder_window(dt=None):
    if dt is None:
        dt = now_ist()

    monthly_day = last_sunday_of_month(dt)
    days_left = (monthly_day.date() - dt.date()).days

    return 0 <= days_left <= MONTHLY_REMINDER_DAYS_BEFORE


async def safe_dm(user: discord.User | discord.Member, message: str):
    try:
        await user.send(message)
        return True
    except discord.Forbidden:
        return False
    except discord.HTTPException:
        return False


async def dm_users_by_ids(guild: discord.Guild, user_ids, message: str):
    failed = []

    for user_id in user_ids:
        member = guild.get_member(int(user_id))

        if member is None:
            try:
                member = await guild.fetch_member(int(user_id))
            except Exception:
                failed.append(user_id)
                continue

        success = await safe_dm(member, message)

        if not success:
            failed.append(user_id)

        # Small delay to avoid rate limits
        await asyncio.sleep(0.5)

    return failed


async def notify_admin_dm_failures(guild: discord.Guild, failed_ids, context: str):
    if not failed_ids:
        return

    admin_channel = get_text_channel_by_name(guild, TOURNAMENT_CODE_CHANNEL_NAME)

    if admin_channel:
        failed_text = "\n".join([f"<@{uid}> (`{uid}`)" for uid in failed_ids])
        await admin_channel.send(
            f"⚠️ I could not DM some users for **{context}**.\n"
            f"They may have DMs disabled:\n{failed_text}"
        )


# =========================================================
# SERVICE TICKET TRANSCRIPT
# =========================================================

async def create_ticket_transcript(channel: discord.TextChannel) -> discord.File:
    messages = []

    async for msg in channel.history(limit=None, oldest_first=True):
        time_text = msg.created_at.strftime("%Y-%m-%d %H:%M:%S")
        author_text = f"{msg.author} ({msg.author.id})"

        content = msg.content if msg.content else ""

        if msg.embeds:
            content += "\n[Embed message]"

        if msg.attachments:
            attachment_links = "\n".join(att.url for att in msg.attachments)
            content += f"\n[Attachments]\n{attachment_links}"

        messages.append(f"[{time_text}] {author_text}:\n{content}\n")

    transcript_text = (
        f"CLOUD PLAYZZ Ticket Transcript\n"
        f"Channel: #{channel.name}\n"
        f"Created transcript at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        f"{'-' * 50}\n\n"
        + "\n".join(messages)
    )

    transcript_bytes = BytesIO(transcript_text.encode("utf-8"))
    return discord.File(transcript_bytes, filename=f"{channel.name}-transcript.txt")


# =========================================================
# SERVICE TICKET CLOSE BUTTONS
# =========================================================

class CloseConfirmView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=60)

    @discord.ui.button(
        label="Yes, Close Ticket",
        emoji="✅",
        style=discord.ButtonStyle.danger,
        custom_id="confirm_close_ticket"
    )
    async def confirm_close(self, interaction: discord.Interaction, button: discord.ui.Button):
        channel = interaction.channel
        guild = interaction.guild

        if guild is None or not isinstance(channel, discord.TextChannel):
            await interaction.response.send_message(
                "This action can only be used inside a server ticket channel.",
                ephemeral=True
            )
            return

        if not is_ticket_channel(channel):
            await interaction.response.send_message("This is not a ticket channel.", ephemeral=True)
            return

        if not is_admin_or_builder(interaction.user):
            await interaction.response.send_message("Only admins/builders can close tickets.", ephemeral=True)
            return

        await interaction.response.defer()

        admin_channel = get_text_channel_by_name(guild, ADMIN_CHANNEL_NAME)

        try:
            transcript_file = await create_ticket_transcript(channel)

            if admin_channel:
                close_embed = discord.Embed(
                    title="Ticket Closed",
                    description=(
                        f"Ticket `{channel.name}` was closed by {interaction.user.mention}.\n"
                        "Transcript is attached below."
                    ),
                    color=discord.Color.red()
                )
                await admin_channel.send(embed=close_embed, file=transcript_file)
        except Exception as e:
            if admin_channel:
                await admin_channel.send(
                    f"Could not create transcript for `{channel.name}`.\nError: `{e}`"
                )

        await channel.send(
            f"🔒 Ticket closed by {interaction.user.mention}.\n"
            f"This channel will be deleted in {TICKET_CLOSE_DELAY_SECONDS} seconds."
        )

        await asyncio.sleep(TICKET_CLOSE_DELAY_SECONDS)

        try:
            await channel.delete(reason=f"Ticket closed by {interaction.user}")
        except discord.Forbidden:
            if admin_channel:
                await admin_channel.send(
                    f"I could not delete `{channel.name}`. Please give me **Manage Channels** permission."
                )

    @discord.ui.button(
        label="Cancel",
        emoji="❌",
        style=discord.ButtonStyle.secondary,
        custom_id="cancel_close_ticket"
    )
    async def cancel_close(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(
            content="Ticket close cancelled.",
            view=None
        )


class TicketControlView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Close Ticket",
        emoji="🔒",
        style=discord.ButtonStyle.danger,
        custom_id="close_ticket_button"
    )
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        channel = interaction.channel

        if not isinstance(channel, discord.TextChannel) or not is_ticket_channel(channel):
            await interaction.response.send_message(
                "This button can only be used inside a ticket channel.",
                ephemeral=True
            )
            return

        if not is_admin_or_builder(interaction.user):
            await interaction.response.send_message("Only admins/builders can close tickets.", ephemeral=True)
            return

        await interaction.response.send_message(
            "Are you sure you want to close this ticket? A transcript will be sent to the admin channel.",
            view=CloseConfirmView(),
            ephemeral=False
        )


# =========================================================
# SERVICE BUTTON VIEW
# =========================================================

class ServiceView(discord.ui.View):
    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(
        label="Server Build",
        style=discord.ButtonStyle.primary,
        custom_id="service_server_build"
    )
    async def server_build(self, interaction: discord.Interaction, button: discord.ui.Button):
        await create_service_ticket(interaction, "Server Build")

    @discord.ui.button(
        label="Automatic Bot Build",
        style=discord.ButtonStyle.success,
        custom_id="service_auto_bot_build"
    )
    async def auto_bot_build(self, interaction: discord.Interaction, button: discord.ui.Button):
        await create_service_ticket(interaction, "Automatic Bot Build")

    @discord.ui.button(
        label="Own Bot Build",
        style=discord.ButtonStyle.secondary,
        custom_id="service_own_bot_build"
    )
    async def own_bot_build(self, interaction: discord.Interaction, button: discord.ui.Button):
        await create_service_ticket(interaction, "Own Bot Build")


# =========================================================
# SUNDAY TOURNAMENT REGISTRATION BUTTON
# =========================================================

class SundayRegisterView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Register for Sunday Tournament",
        emoji="🏆",
        style=discord.ButtonStyle.success,
        custom_id="sunday_tournament_register"
    )
    async def register(self, interaction: discord.Interaction, button: discord.ui.Button):
        user_id = str(interaction.user.id)

        if not data["sunday"]["registration_open"]:
            await interaction.response.send_message(
                "Registration is currently closed.",
                ephemeral=True
            )
            return

        if user_id in data["sunday"]["registered_user_ids"]:
            await interaction.response.send_message(
                "You are already registered for this Sunday tournament.",
                ephemeral=True
            )
            return

        data["sunday"]["registered_user_ids"].append(user_id)
        save_data(data)

        await interaction.response.send_message(
            "✅ You have successfully registered for this Sunday’s tournament. Check your DM for confirmation.",
            ephemeral=True
        )

        await safe_dm(
            interaction.user,
            "✅ **Sunday Tournament Registration Successful!**\n\n"
            "You have registered for this Sunday’s CLOUD PLAYZZ tournament.\n"
            "Please stay active. The room code will be sent to you when the live stream starts."
        )


# =========================================================
# MAIN BOT CLASS
# =========================================================

class CloudPlayzzBot(discord.Client):
    async def setup_hook(self):
        # Persistent buttons after restart
        self.add_view(ServiceView(self))
        self.add_view(TicketControlView())
        self.add_view(SundayRegisterView())
        setup_sponsor_feature(self)

        if not tournament_scheduler.is_running():
            tournament_scheduler.start()

    async def on_ready(self):
        print("==========================================")
        print("CLOUD PLAYZZ BOT STARTED")
        print("==========================================")
        print()
        print("Connected as:")
        print(self.user)
        print()
        print("Loaded Modules:")
        print("✅ Introduction")
        print("✅ Service Tickets")
        print("✅ Tournament")
        print("✅ Sponsors")
        print()
        print("Server Count:")
        print(len(self.guilds))
        print()
        print("Ready!")

        for guild in self.guilds:
            await send_service_panel(guild, self)
            await send_sponsor_panel(guild, self)

    async def on_message(self, message):
        if message.author.bot:
            return

        # Service panel manual admin command
        if message.content.lower().strip() == "!panel":
            if message.author.guild_permissions.administrator:
                await send_service_panel(message.guild, self)
            else:
                await message.reply("Only admins can use this command.")
            return
        
        sponsor_handled = await handle_sponsor_message(message, self)
        if sponsor_handled:
          return

        # Tournament commands
        command_handled = await handle_tournament_commands(message)
        if command_handled:
            return

        # Introduction auto reply
        await handle_introduction_message(message)


client = CloudPlayzzBot(intents=intents)


# =========================================================
# AUTOMATIC TOURNAMENT SCHEDULER
# =========================================================

@tasks.loop(minutes=1)
async def tournament_scheduler():
    dt = now_ist()

    for guild in client.guilds:
        # Friday registration open
        if dt.weekday() == 4 and dt.hour == FRIDAY_REGISTRATION_OPEN.hour and dt.minute == FRIDAY_REGISTRATION_OPEN.minute:
            if data["sunday"]["last_open_date"] != date_key(dt):
                await open_sunday_registration(guild)
                data["sunday"]["last_open_date"] = date_key(dt)
                save_data(data)

        # Friday registration close
        if dt.weekday() == 4 and dt.hour == FRIDAY_REGISTRATION_CLOSE.hour and dt.minute == FRIDAY_REGISTRATION_CLOSE.minute:
            if data["sunday"]["last_close_date"] != date_key(dt):
                await close_sunday_registration(guild)
                data["sunday"]["last_close_date"] = date_key(dt)
                save_data(data)

        # Sunday tournament alert
        if dt.weekday() == 6 and dt.hour == SUNDAY_TOURNAMENT_ALERT.hour and dt.minute == SUNDAY_TOURNAMENT_ALERT.minute:
            if data["sunday"]["last_sunday_alert_date"] != date_key(dt):
                await send_sunday_tournament_alert(guild)
                data["sunday"]["last_sunday_alert_date"] = date_key(dt)
                save_data(data)

        # Monthly reminders to qualified players
        if is_within_monthly_reminder_window(dt) and dt.hour == MONTHLY_REMINDER_TIME.hour and dt.minute == MONTHLY_REMINDER_TIME.minute:
            if data["monthly"]["last_monthly_reminder_date"] != date_key(dt):
                await send_monthly_qualifier_reminder(guild)
                data["monthly"]["last_monthly_reminder_date"] = date_key(dt)
                save_data(data)

        # Monthly tournament day announcement
        if is_monthly_tournament_day(dt) and dt.hour == MONTHLY_TOURNAMENT_ALERT.hour and dt.minute == MONTHLY_TOURNAMENT_ALERT.minute:
            if data["monthly"]["last_monthly_alert_month"] != month_key(dt):
                await send_monthly_tournament_alert(guild)
                data["monthly"]["last_monthly_alert_month"] = month_key(dt)
                save_data(data)


@tournament_scheduler.before_loop
async def before_tournament_scheduler():
    await client.wait_until_ready()


# =========================================================
# FEATURE 1: INTRODUCTION AUTO REPLY
# =========================================================

async def handle_introduction_message(message):
    channel_name = message.channel.name.lower()

    category_name = ""
    if message.channel.category:
        category_name = message.channel.category.name.lower()

    is_intro_place = any(
        keyword in channel_name or keyword in category_name
        for keyword in INTRO_KEYWORDS
    )

    if not is_intro_place:
        return

    user_text = message.content.lower().strip()

    greetings = ["hi", "hello", "hey", "hii", "hai", "vanakkam"]

    intro_keywords = [
        "my name is",
        "i am",
        "i'm",
        "im ",
        "from",
        "age",
        "i like",
        "my hobby",
        "favorite game",
        "favourite game"
    ]

    if user_text in greetings:
        await message.reply(
            f"Hey {message.author.mention}! 👋 Welcome to **CLOUD PLAYZZ**!\n\n"
            "Please introduce yourself using this format:\n"
            "**Name:**\n"
            "**Age:**\n"
            "**From:**\n"
            "**Favourite game:**"
        )

    elif len(user_text) > 15 and any(word in user_text for word in intro_keywords):
        await message.reply(
            f"Nice to meet you, {message.author.mention}! 😎\n"
            "Welcome to **CLOUD PLAYZZ**. We hope you enjoy your time here!"
        )


# =========================================================
# FEATURE 2: SERVICE PANEL
# =========================================================

async def send_service_panel(guild, bot):
    service_channel = None

    for channel in guild.text_channels:
        if SERVICE_CHANNEL_KEYWORD in channel.name.lower():
            service_channel = channel
            break

    if service_channel is None:
        print("Service channel not found.")
        return

    async for msg in service_channel.history(limit=50):
        if msg.author == bot.user and msg.embeds:
            if msg.embeds[0].title == "Discord Server & Bot Services":
                print("Service panel already exists.")
                return

    embed = discord.Embed(
        title="Discord Server & Bot Services",
        description=(
            "Welcome! Please choose the service you need from the buttons below.\n\n"
            "**Available Services:**\n"
            "• Server Build\n"
            "• Automatic Bot Build\n"
            "• Own Custom Bot Build\n\n"
            "```"
            "Note: After choosing an option, a private ticket will be created. "
            "Only you and the admin/building team can view and reply there, "
            "so you can share your requirements freely."
            "```"
        ),
        color=discord.Color.blue()
    )

    embed.set_footer(text="CLOUD PLAYZZ Services")

    await service_channel.send(embed=embed, view=ServiceView(bot))
    print("Service panel sent.")


# =========================================================
# FEATURE 3: PRIVATE SERVICE TICKET + ADMIN DETAILS
# =========================================================

async def create_service_ticket(interaction: discord.Interaction, service_name: str):
    guild = interaction.guild
    user = interaction.user

    if guild is None:
        await interaction.response.send_message(
            "This service can only be used inside the server.",
            ephemeral=True
        )
        return

    ticket_name = f"ticket-{user.name.lower()}-{user.id % 10000}"

    existing_ticket = discord.utils.get(guild.text_channels, name=ticket_name)

    if existing_ticket:
        await interaction.response.send_message(
            f"You already have an open ticket: {existing_ticket.mention}",
            ephemeral=True
        )
        return

    overwrites = {
        guild.default_role: discord.PermissionOverwrite(view_channel=False),
        user: discord.PermissionOverwrite(
            view_channel=True,
            send_messages=True,
            read_message_history=True
        ),
        guild.me: discord.PermissionOverwrite(
            view_channel=True,
            send_messages=True,
            read_message_history=True,
            manage_channels=True
        )
    }

    for role in guild.roles:
        if role.name in ADMIN_ROLE_NAMES:
            overwrites[role] = discord.PermissionOverwrite(
                view_channel=True,
                send_messages=True,
                read_message_history=True,
                manage_channels=True
            )

    try:
        ticket_channel = await guild.create_text_channel(
            name=ticket_name,
            overwrites=overwrites,
            category=interaction.channel.category,
            reason=f"Service ticket created for {user}"
        )
    except discord.Forbidden:
        await interaction.response.send_message(
            "I do not have permission to create ticket channels. Please give me **Manage Channels** permission.",
            ephemeral=True
        )
        return

    await interaction.response.send_message(
        f"Your private ticket has been created: {ticket_channel.mention}",
        ephemeral=True
    )

    intro_embed = discord.Embed(
        title=f"{service_name} Request",
        description=(
            f"Hello {user.mention}, thank you for contacting **CLOUD PLAYZZ Services**.\n\n"
            "Please enter your details in one message so our builders can contact you.\n\n"
            "**Copy and fill this format:**\n"
            "```text\n"
            "Name:\n"
            "Discord ID:\n"
            "Instagram ID / Phone Number / Email:\n"
            "Service Needed:\n"
            "Your Requirements:\n"
            "Budget if any:\n"
            "Preferred Contact Method:\n"
            "```\n"
            "**Privacy Note:** This ticket is visible only to you and the admin/building team."
        ),
        color=discord.Color.green()
    )

    await ticket_channel.send(embed=intro_embed, view=TicketControlView())

    def check(message):
        return message.author.id == user.id and message.channel.id == ticket_channel.id

    try:
        customer_message = await client.wait_for("message", check=check, timeout=900)
    except asyncio.TimeoutError:
        await ticket_channel.send(
            f"{user.mention}, the ticket timed out because no details were entered. "
            "You can still send your details here when you are ready."
        )
        return

    admin_channel = get_text_channel_by_name(guild, ADMIN_CHANNEL_NAME)

    admin_embed = discord.Embed(
        title="New Service Request",
        color=discord.Color.orange()
    )

    admin_embed.add_field(name="Customer", value=f"{user.mention}\n`{user}`", inline=False)
    admin_embed.add_field(name="Selected Service", value=service_name, inline=False)
    admin_embed.add_field(name="Ticket Channel", value=ticket_channel.mention, inline=False)
    admin_embed.add_field(name="Customer Details", value=customer_message.content[:1000], inline=False)

    if admin_channel:
        await admin_channel.send(embed=admin_embed)
    else:
        await ticket_channel.send(
            "Warning: Admin channel was not found. Please check `ADMIN_CHANNEL_NAME` in the code."
        )

    await ticket_channel.send(
        f"Thank you for contacting us, {user.mention}! ✅\n"
        "Your request has been received successfully. Our team will review your details and contact you soon. Stay tuned!"
    )


# =========================================================
# FEATURE 4: SUNDAY TOURNAMENT FUNCTIONS
# =========================================================

async def open_sunday_registration(guild: discord.Guild):
    sunday_channel = get_text_channel_by_keyword(guild, SUNDAY_CHANNEL_KEYWORD)

    if sunday_channel is None:
        print("Sunday tournament channel not found.")
        return

    data["sunday"]["registration_open"] = True
    data["sunday"]["registered_user_ids"] = []
    data["sunday"]["registration_message_id"] = None
    save_data(data)

    embed = discord.Embed(
        title="🏆 Sunday Tournament Registration Open!",
        description=(
            "Click the button below to register for this Sunday’s tournament.\n\n"
            "**Registration Time:**\n"
            "Friday 10:00 AM to Friday 10:00 PM\n\n"
            "**Important:**\n"
            "Registered players will receive the room code through DM when the live stream starts."
        ),
        color=discord.Color.green()
    )

    embed.set_footer(text="CLOUD PLAYZZ Sunday Tournament")

    msg = await sunday_channel.send(embed=embed, view=SundayRegisterView())

    data["sunday"]["registration_message_id"] = msg.id
    save_data(data)


async def close_sunday_registration(guild: discord.Guild):
    sunday_channel = get_text_channel_by_keyword(guild, SUNDAY_CHANNEL_KEYWORD)

    data["sunday"]["registration_open"] = False
    save_data(data)

    registered_count = len(data["sunday"]["registered_user_ids"])

    if sunday_channel:
        await sunday_channel.send(
            "🔒 **Sunday Tournament Registration Closed!**\n\n"
            f"Total registered players: **{registered_count}**\n"
            "Registered players will receive the room code through DM when the tournament starts."
        )


async def send_sunday_tournament_alert(guild: discord.Guild):
    registered_ids = data["sunday"]["registered_user_ids"]

    general_channel = get_text_channel_by_name(guild, GENERAL_CHANNEL_NAME)
    sunday_channel = get_text_channel_by_keyword(guild, SUNDAY_CHANNEL_KEYWORD)

    if general_channel:
        await general_channel.send(
            "🔥 **CLOUD PLAYZZ Sunday Tournament is happening today!**\n\n"
            "Join the live stream and watch the match. Good luck to all registered players!"
        )

    if sunday_channel:
        await sunday_channel.send(
            "🏆 **Sunday Tournament Day!**\n\n"
            "Registered players, stay ready. The room code will be sent through DM when the live stream starts."
        )

    dm_message = (
        "🏆 **Sunday Tournament Reminder**\n\n"
        "The CLOUD PLAYZZ Sunday Tournament is happening today!\n"
        "Stay ready. The room code will be sent when the live stream starts."
    )

    failed = await dm_users_by_ids(guild, registered_ids, dm_message)
    await notify_admin_dm_failures(guild, failed, "Sunday tournament reminder")


async def send_sunday_room_code(guild: discord.Guild, room_code: str):
    registered_ids = data["sunday"]["registered_user_ids"]

    if not registered_ids:
        return "No registered players found for this Sunday tournament."

    message = (
        "🎮 **Sunday Tournament Room Code**\n\n"
        f"**Room Code:** `{room_code}`\n\n"
        "Join quickly and be ready for the match. Good luck!"
    )

    failed = await dm_users_by_ids(guild, registered_ids, message)
    await notify_admin_dm_failures(guild, failed, "Sunday room code")

    return f"Room code sent to **{len(registered_ids) - len(failed)}** registered players. Failed DMs: **{len(failed)}**."


async def announce_sunday_winners(guild: discord.Guild, winners):
    winner_ids = [str(winner.id) for winner in winners]

    for winner_id in winner_ids:
        if winner_id not in data["monthly"]["qualified_user_ids"]:
            data["monthly"]["qualified_user_ids"].append(winner_id)

    data["monthly"]["weekly_winners_history"].append({
        "date": date_key(),
        "winners": winner_ids
    })

    save_data(data)

    announcement = (
        "🏆 **Sunday Tournament Winners**\n\n"
        f"🥇 **1st Place:** {winners[0].mention}\n"
        f"🥈 **2nd Place:** {winners[1].mention}\n"
        f"🥉 **3rd Place:** {winners[2].mention}\n\n"
        "Congratulations! These players are now qualified for the **Monthly End Tournament**."
    )

    channels = [
        get_text_channel_by_keyword(guild, SUNDAY_CHANNEL_KEYWORD),
        get_text_channel_by_name(guild, GENERAL_CHANNEL_NAME),
        get_text_channel_by_keyword(guild, MONTHLY_CHANNEL_KEYWORD)
    ]

    for channel in channels:
        if channel:
            await channel.send(announcement)

    dm_message = (
        "🎉 **Congratulations!**\n\n"
        "You placed in the Top 3 of the Sunday Tournament.\n"
        "You are now qualified for the Monthly End Tournament!"
    )

    failed = await dm_users_by_ids(guild, winner_ids, dm_message)
    await notify_admin_dm_failures(guild, failed, "Sunday winners monthly qualification")


# =========================================================
# FEATURE 5: MONTHLY TOURNAMENT FUNCTIONS
# =========================================================

async def send_monthly_qualifier_reminder(guild: discord.Guild):
    qualified_ids = data["monthly"]["qualified_user_ids"]

    if not qualified_ids:
        return

    monthly_day = last_sunday_of_month()
    days_left = (monthly_day.date() - now_ist().date()).days

    dm_message = (
        "🏆 **Monthly End Tournament Reminder**\n\n"
        "You are qualified for the Monthly End Tournament because you placed Top 3 in a Sunday Tournament.\n"
        f"Monthly tournament day is coming soon. Days left: **{days_left}**.\n\n"
        "Stay ready for the final match!"
    )

    failed = await dm_users_by_ids(guild, qualified_ids, dm_message)
    await notify_admin_dm_failures(guild, failed, "Monthly qualifier reminder")


async def send_monthly_tournament_alert(guild: discord.Guild):
    general_channel = get_text_channel_by_name(guild, GENERAL_CHANNEL_NAME)
    monthly_channel = get_text_channel_by_keyword(guild, MONTHLY_CHANNEL_KEYWORD)

    announcement = (
        "🔥 **Monthly End Tournament starts today!**\n\n"
        "Only qualified Sunday Tournament winners can participate.\n"
        "Everyone else can join the live stream and watch the final match!"
    )

    if general_channel:
        await general_channel.send(announcement)

    if monthly_channel:
        await monthly_channel.send(announcement)

    qualified_ids = data["monthly"]["qualified_user_ids"]

    dm_message = (
        "👑 **Monthly End Tournament Day!**\n\n"
        "You are qualified for today’s Monthly End Tournament.\n"
        "Stay ready. The room code will be sent when the live stream starts."
    )

    failed = await dm_users_by_ids(guild, qualified_ids, dm_message)
    await notify_admin_dm_failures(guild, failed, "Monthly tournament day alert")


async def send_monthly_room_code(guild: discord.Guild, room_code: str):
    qualified_ids = data["monthly"]["qualified_user_ids"]

    if not qualified_ids:
        return "No monthly qualified players found."

    message = (
        "🎮 **Monthly End Tournament Room Code**\n\n"
        f"**Room Code:** `{room_code}`\n\n"
        "Join quickly. This is the final tournament. Good luck!"
    )

    failed = await dm_users_by_ids(guild, qualified_ids, message)
    await notify_admin_dm_failures(guild, failed, "Monthly room code")

    return f"Monthly room code sent to **{len(qualified_ids) - len(failed)}** qualified players. Failed DMs: **{len(failed)}**."


async def announce_monthly_winner(guild: discord.Guild, winner: discord.Member):
    announcement = (
        "👑 **Monthly End Tournament Champion**\n\n"
        f"🥇 **Winner:** {winner.mention}\n\n"
        "Congratulations! You are the official **CLOUD PLAYZZ Monthly Champion**!"
    )

    channels = [
        get_text_channel_by_keyword(guild, MONTHLY_CHANNEL_KEYWORD),
        get_text_channel_by_name(guild, GENERAL_CHANNEL_NAME),
        get_text_channel_by_keyword(guild, SUNDAY_CHANNEL_KEYWORD)
    ]

    for channel in channels:
        if channel:
            await channel.send(announcement)

    await safe_dm(
        winner,
        "👑 **Congratulations!**\n\n"
        "You are the CLOUD PLAYZZ Monthly End Tournament Champion!"
    )


# =========================================================
# FEATURE 6: TOURNAMENT ADMIN COMMANDS
# Use only inside #tournament-code
# =========================================================

async def handle_tournament_commands(message: discord.Message):
    if not message.guild:
        return False

    content = message.content.strip()
    lower = content.lower()

    tournament_code_channel = get_text_channel_by_name(message.guild, TOURNAMENT_CODE_CHANNEL_NAME)

    # Only listen to tournament commands in tournament-code channel
    if tournament_code_channel is None or message.channel.id != tournament_code_channel.id:
        return False

    if not lower.startswith("!"):
        return False

    if not is_admin_or_builder(message.author):
        await message.reply("Only admins/builders can use tournament commands.")
        return True

    if lower == "!tcommands":
        await message.channel.send(
            "**Tournament Commands**\n\n"
            "`!openreg` - manually open Sunday registration\n"
            "`!closereg` - manually close Sunday registration\n"
            "`!sundayalert` - manually send Sunday tournament alert\n"
            "`!sundayroom <room_code>` - DM room code to registered Sunday players\n"
            "`!sundaywinners @1st @2nd @3rd` - announce Sunday winners and save monthly qualifiers\n"
            "`!monthlyalert` - announce monthly tournament day\n"
            "`!monthlyroom <room_code>` - DM room code to monthly qualifiers\n"
            "`!monthlywinner @winner` - announce monthly champion\n"
            "`!qualifiers` - show monthly qualified players\n"
            "`!registered` - show Sunday registered players\n"
            "`!resetweek` - clear Sunday registrations\n"
            "`!resetmonth` - clear monthly qualifiers"
        )
        return True

    if lower == "!openreg":
        await open_sunday_registration(message.guild)
        await message.reply("✅ Sunday registration opened manually.")
        return True

    if lower == "!closereg":
        await close_sunday_registration(message.guild)
        await message.reply("🔒 Sunday registration closed manually.")
        return True

    if lower == "!sundayalert":
        await send_sunday_tournament_alert(message.guild)
        await message.reply("✅ Sunday tournament alert sent.")
        return True

    if lower.startswith("!sundayroom"):
        parts = content.split(maxsplit=1)

        if len(parts) < 2:
            await message.reply("Usage: `!sundayroom <room_code>`")
            return True

        room_code = parts[1].strip()
        result = await send_sunday_room_code(message.guild, room_code)
        await message.reply(f"✅ {result}")
        return True

    if lower.startswith("!sundaywinners"):
        if len(message.mentions) < 3:
            await message.reply("Usage: `!sundaywinners @1st @2nd @3rd`")
            return True

        winners = message.mentions[:3]
        await announce_sunday_winners(message.guild, winners)
        await message.reply("✅ Sunday winners announced and saved as monthly qualifiers.")
        return True

    if lower == "!monthlyalert":
        await send_monthly_tournament_alert(message.guild)
        await message.reply("✅ Monthly tournament alert sent.")
        return True

    if lower.startswith("!monthlyroom"):
        parts = content.split(maxsplit=1)

        if len(parts) < 2:
            await message.reply("Usage: `!monthlyroom <room_code>`")
            return True

        room_code = parts[1].strip()
        result = await send_monthly_room_code(message.guild, room_code)
        await message.reply(f"✅ {result}")
        return True

    if lower.startswith("!monthlywinner"):
        if len(message.mentions) < 1:
            await message.reply("Usage: `!monthlywinner @winner`")
            return True

        winner = message.mentions[0]
        await announce_monthly_winner(message.guild, winner)
        await message.reply("✅ Monthly champion announced.")
        return True

    if lower == "!qualifiers":
        qualified_ids = data["monthly"]["qualified_user_ids"]
        await message.channel.send(
            "👑 **Monthly Qualified Players**\n\n"
            f"{get_mention_list(qualified_ids)}"
        )
        return True

    if lower == "!registered":
        registered_ids = data["sunday"]["registered_user_ids"]
        await message.channel.send(
            "🏆 **Sunday Registered Players**\n\n"
            f"{get_mention_list(registered_ids)}"
        )
        return True

    if lower == "!resetweek":
        data["sunday"]["registration_open"] = False
        data["sunday"]["registered_user_ids"] = []
        data["sunday"]["registration_message_id"] = None
        save_data(data)
        await message.reply("✅ Sunday registration data has been reset.")
        return True

    if lower == "!resetmonth":
        data["monthly"]["qualified_user_ids"] = []
        data["monthly"]["weekly_winners_history"] = []
        save_data(data)
        await message.reply("✅ Monthly qualifier data has been reset.")
        return True

    return False


# =========================================================
# START BOT
# =========================================================

def start_bot():
    if not TOKEN:
        print("ERROR: DISCORD_BOT_TOKEN environment variable not found.")
        sys.exit(1)

    print("Starting CLOUD PLAYZZ Full Bot...")

    try:
        client.run(TOKEN)
    except discord.LoginFailure:
        print("Invalid Discord Token.")
        sys.exit(1)
    except (OSError, TimeoutError, ConnectionError, asyncio.TimeoutError):
        print("Network connection failed.")
        sys.exit(1)
    except Exception as exc:
        print(f"Startup failed: {exc}")
        sys.exit(1)


if __name__ == "__main__":
    start_bot()
